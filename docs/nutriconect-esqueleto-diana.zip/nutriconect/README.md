# NutriConect

Sistema em Java Spring Boot que conecta empresas com sobra de alimentos a ONGs (ODS 2 - Fome Zero).

## Tratamento global de erros
Classe `GlobalExceptionHandler` (`@RestControllerAdvice`) em `src/main/java/br/com/nutriconect/exception`.
Erros viram JSON amigável em vez de erro 500 do servidor.

## Como rodar
Requisitos: JDK 17+ e Maven.

    mvn spring-boot:run

## Testes rápidos (porta 8080)
| Requisição | Resultado |
|---|---|
| `POST /receitas` `{"ingredientes":[]}` | 400 "Ingrediente não informado" |
| `POST /receitas` `{"ingredientes":["arroz","casca de abóbora"]}` | 200 receita |
| `POST /receitas` `{"ingredientes":["erro-ia"]}` | 503 IA indisponível |
| `GET /alimentos/999` | 404 |
| `POST /doacoes/reservar` | 422 regra de negócio |
| `GET /teste-500` | 500 amigável |
