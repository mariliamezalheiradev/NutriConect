package br.com.nutriconect.dto;

public record ReceitaResponse(String receita) {}
