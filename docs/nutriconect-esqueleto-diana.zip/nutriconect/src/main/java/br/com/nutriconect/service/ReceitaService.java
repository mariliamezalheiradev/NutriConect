package br.com.nutriconect.service;

import br.com.nutriconect.dto.ReceitaRequest;
import br.com.nutriconect.dto.ReceitaResponse;
import br.com.nutriconect.exception.IAIndisponivelException;
import org.springframework.stereotype.Service;

@Service
public class ReceitaService {

    /**
     * Simulação da IA generativa. Troque pela chamada real da API depois.
     * Para testar o erro 503, envie o ingrediente "erro-ia".
     */
    public ReceitaResponse gerar(ReceitaRequest req) {
        try {
            if (req.ingredientes().contains("erro-ia")) {
                throw new RuntimeException("Timeout simulado na API de IA");
            }
            String lista = String.join(", ", req.ingredientes());
            return new ReceitaResponse(
                    "Receita de aproveitamento total com: " + lista
                            + ". 1) Pique tudo. 2) Refogue com alho e cebola. 3) Tempere e sirva.");
        } catch (Exception e) {
            throw new IAIndisponivelException("Falha na API de IA", e);
        }
    }
}
