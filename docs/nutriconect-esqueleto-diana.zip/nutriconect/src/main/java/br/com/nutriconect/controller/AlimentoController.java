package br.com.nutriconect.controller;

import br.com.nutriconect.exception.RecursoNaoEncontradoException;
import br.com.nutriconect.exception.RegraNegocioException;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

/** Controller de EXEMPLO só para demonstrar o handler. Substitua pelo real. */
@RestController
public class AlimentoController {

    @GetMapping("/alimentos/{id}")
    public Map<String, Object> buscar(@PathVariable Long id) {
        if (id != 1L) {
            throw new RecursoNaoEncontradoException("Alimento não encontrado: id " + id);
        }
        return Map.of("id", 1, "nome", "Arroz cozido", "lista", "Disponível para Doação");
    }

    @PostMapping("/doacoes/reservar")
    public void reservar() {
        throw new RegraNegocioException(
                "Só é possível reservar itens da Lista 2 (Disponível para Doação).");
    }

    @GetMapping("/teste-500")
    public void erroInesperado() {
        throw new IllegalStateException("Erro interno de propósito");
    }
}
