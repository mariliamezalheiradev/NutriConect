package br.com.nutriconect.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;

import java.util.List;

public record ReceitaRequest(
        @NotEmpty(message = "Ingrediente não informado")
        List<@NotBlank(message = "Ingrediente em branco") String> ingredientes
) {}
