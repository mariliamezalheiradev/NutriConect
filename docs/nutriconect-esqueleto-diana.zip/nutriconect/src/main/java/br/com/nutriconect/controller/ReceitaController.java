package br.com.nutriconect.controller;

import br.com.nutriconect.dto.ReceitaRequest;
import br.com.nutriconect.dto.ReceitaResponse;
import br.com.nutriconect.service.ReceitaService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ReceitaController {

    private final ReceitaService service;

    public ReceitaController(ReceitaService service) {
        this.service = service;
    }

    @PostMapping("/receitas")
    public ReceitaResponse gerar(@Valid @RequestBody ReceitaRequest req) {
        return service.gerar(req);
    }
}
