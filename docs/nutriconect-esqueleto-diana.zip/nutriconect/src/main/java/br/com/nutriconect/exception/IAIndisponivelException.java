package br.com.nutriconect.exception;

/** Lançar quando a API de IA (receitas) falhar, der timeout ou estiver fora do ar. */
public class IAIndisponivelException extends RuntimeException {
    public IAIndisponivelException(String mensagem, Throwable causa) {
        super(mensagem, causa);
    }
}
