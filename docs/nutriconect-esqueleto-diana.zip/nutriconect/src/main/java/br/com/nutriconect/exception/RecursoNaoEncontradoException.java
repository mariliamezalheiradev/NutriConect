package br.com.nutriconect.exception;

/** Lançar quando um alimento, doação, ONG, pedido etc. não existir. */
public class RecursoNaoEncontradoException extends RuntimeException {
    public RecursoNaoEncontradoException(String mensagem) {
        super(mensagem);
    }
}
