package br.com.nutriconect.exception;

/**
 * Lançar quando uma regra de negócio for violada.
 * Ex.: reservar alimento que não está na Lista 2, validar QR Code já usado.
 */
public class RegraNegocioException extends RuntimeException {
    public RegraNegocioException(String mensagem) {
        super(mensagem);
    }
}
